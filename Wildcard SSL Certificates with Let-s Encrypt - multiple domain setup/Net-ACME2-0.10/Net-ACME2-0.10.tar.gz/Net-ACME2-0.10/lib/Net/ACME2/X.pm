package Net::ACME2::X;

use strict;
use warnings;

use parent qw( X::Tiny );

1;
