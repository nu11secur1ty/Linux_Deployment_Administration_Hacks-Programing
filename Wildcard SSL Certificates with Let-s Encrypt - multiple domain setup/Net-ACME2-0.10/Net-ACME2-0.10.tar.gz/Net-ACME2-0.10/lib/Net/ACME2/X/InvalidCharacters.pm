package Net::ACME2::X::InvalidCharacters;

use strict;
use warnings;

use parent qw( Net::ACME2::X::Base );

#named args required:
#
#   value
#

1;
