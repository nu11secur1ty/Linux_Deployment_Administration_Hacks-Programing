package Net::ACME2::Constants;

#----------------------------------------------------------------------
# Please do NOT reference these from outside the Net::ACME2 namespace!
#----------------------------------------------------------------------

use strict;
use warnings;

our $VERSION = '0.10';

1;
